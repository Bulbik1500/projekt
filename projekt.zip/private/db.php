<?php
// Data base info for use in diffrent files
$DB_servername = "localhost";
$DB_username = "root";
$DB_password = "";
$DB_name = "serwisdb";